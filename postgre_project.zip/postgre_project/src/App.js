import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [categories, setCategories] = useState([]);
  const [newCategory, setNewCategory] = useState({ name: '', description: '' });
  const [editCategory, setEditCategory] = useState({ categoryid: null, name: '', description: '' });
  const [triggerEvents, setTriggerEvents] = useState([]);

  useEffect(() => {
    fetchCategories();
    // fetchTriggerEvents();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await axios.get('http://localhost:6969/api/categories');
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewCategory({ ...newCategory, [name]: value });
  };

  const handleEditInputChange = (e) => {
    const { name, value } = e.target;
    setEditCategory({ ...editCategory, [name]: value });
  };

  const handleAddCategory = async () => {
    try {
      await axios.post('http://localhost:6969/api/categories', newCategory);
      fetchCategories(); // Refresh the categories after adding a new one
      setNewCategory({ name: '', description: '' });
    } catch (error) {
      console.error('Error adding category', error);
    }
  };

  // const fetchTriggerEvents = async () => {
  //   try {
  //     const response = await axios.get('http://localhost:6969/api/trigger-events');
  //     setTriggerEvents(response.data);
  //   } catch (error) {
  //     console.error('Error fetching trigger events', error);
  //   }
  // };

  const handleEditCategory = async () => {
    try {
      if (editCategory.id) {
        await axios.put(`http://localhost:6969/api/categories/${editCategory.id}`, editCategory);
        fetchCategories(); // Refresh the categories after editing
        setEditCategory({ id: null, name: '', description: '' });
      } else {
        console.error('Invalid edit operation: Category ID is undefined.');
      }
    } catch (error) {
      console.error('Error editing category', error);
    }
  };

  const handleDeleteCategory = async (categoryId) => {
    try {
      if (categoryId) {
        await axios.delete(`http://localhost:6969/api/categories/${categoryId}`);
        fetchCategories(); // Refresh the categories after deletion
      } else {
        console.error('Invalid delete operation: Category ID is undefined.');
      }
    } catch (error) {
      console.error('Error deleting category', error);
    }
  };
  
  

  const handleEditClick = (category) => {
    setEditCategory({ id: category.categoryid, name: category.name, description: category.description });
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Categories CRUD</h1>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Description</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((category) => (
              <tr key={category.categoryid}>
                <td>{category.categoryid}</td>
                <td>{category.name}</td>
                <td>{category.description}</td>
                <td>
                  <button onClick={() => handleEditClick(category)}>Edit</button>
                  <button onClick={() => handleDeleteCategory(category.categoryid)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div>
          <h2>Add New Category</h2>
          <label>
            Name:
            <input type="text" name="name" value={newCategory.name} onChange={handleInputChange} />
          </label>
          <label>
            Description:
            <input type="text" name="description" value={newCategory.description} onChange={handleInputChange} />
          </label>
          <button onClick={handleAddCategory}>Add Category</button>
        </div>

        {editCategory.id && (
          <div>
            <h2>Edit Category</h2>
            <label>
              Name:
              <input type="text" name="name" value={editCategory.name} onChange={handleEditInputChange} />
            </label>
            <label>
              Description:
              <input type="text" name="description" value={editCategory.description} onChange={handleEditInputChange} />
            </label>
            <button onClick={handleEditCategory}>Save Changes</button>
          </div>
        )}

      {/* <h2>Latest Trigger Events</h2>
        <ul>
          {triggerEvents.map((event) => (
            <li key={event.eventID}>
              {event.eventTimestamp}: {event.eventDescription}
            </li>
          ))}
        </ul> */}
      </header>
    </div>
  );
}

export default App;
